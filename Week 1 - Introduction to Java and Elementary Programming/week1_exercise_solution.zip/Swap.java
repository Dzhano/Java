public class Swap {

   public static void main( String[] args ) {
   
      int x = 1, y = 2, temp;
      System.out.printf("values before swap, x = %d, y = %d\n", x, y);      
      temp = x; x = y; y = temp;
      System.out.printf("values after swap, x = %d, y = %d\n", x, y);
 
   }

}
import java.util.Scanner;

public class SimpleInterest {

   public static void main( String[] args ) {
   
      double P, R, T, SI;
      Scanner input = new Scanner(System.in);
      System.out.println("Enter the principal amount: ");
      P = input.nextDouble();    
      System.out.println("Enter the rate of interest: ");
      R = input.nextDouble(); 
      System.out.println("Enter the number of time periods: ");
      T = input.nextDouble(); 
      
      SI = (P * R * T) / 100;
      System.out.printf("Simple Interest = %.2f", SI);
 
   }

}
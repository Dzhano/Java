import java.util.Scanner;

public class CompoundInterest {

   public static void main( String[] args ) {
   
      double P, i, t, CI;
      Scanner input = new Scanner(System.in);
      System.out.println("Enter the principal amount: ");
      P = input.nextDouble();    
      System.out.println("Enter the annual interest rate: ");
      i = input.nextDouble(); 
      System.out.println("Enter the number of years invested: ");
      t = input.nextDouble(); 
      
      CI = P * Math.pow((1 + i), t) - P;
      System.out.printf("Compound Interest = %.2f", CI);
 
   }

}